import Topbar from "./topbar.jsx"

export default function () {
  return {
    components: {
      Topbar
    }
  }
}
